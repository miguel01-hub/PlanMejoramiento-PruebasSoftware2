import http from 'k6/http';
import { check, sleep } from 'k6';

// Configuración simple para probar
export const options = {
  vus: 5,           // 5 usuarios virtuales
  duration: '30s',   // Duración 30 segundos
};

export default function () {
  // Hacer una petición a la página de login de Sauce Demo
  const response = http.get('https://www.saucedemo.com/');
  
  // Verificaciones
  check(response, {
    'status es 200': (r) => r.status === 200,
    'página carga correctamente': (r) => r.body.includes('Sauce Labs'),
    'tiempo respuesta < 2 segundos': (r) => r.timings.duration < 2000,
  });

  sleep(1); // Esperar 1 segundo entre iteraciones
}