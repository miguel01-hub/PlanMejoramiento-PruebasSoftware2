import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  vus: 5,
  duration: "30s",
};

export default function () {
  // Solo probamos que la página principal cargue
  const response = http.get("https://www.saucedemo.com/");

  check(response, {
    "status es 200": (r) => r.status === 200,
    "página carga": (r) => r.body.includes("Sauce Labs"),
    "tiempo < 3000ms": (r) => r.timings.duration < 3000,
  });

  sleep(2);
}
