# PlanMejoramiento-PruebasSoftware2
Framework de automatización E2E (UI, API, Perf) para el Plan de Mejoramiento
