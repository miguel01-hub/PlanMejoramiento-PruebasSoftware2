import LoginPage from "../pages/LoginPage";
import SauceDemoPage from "../pages/PIMPage";

describe("A. Suite Login y Logout", () => {
  beforeEach(() => {
    LoginPage.visit();
  });

  it("HU-001: Login Exitoso con Credenciales Válidas", () => {
    LoginPage.fillCredentials("standard_user", "secret_sauce");
    LoginPage.clickLogin();
    SauceDemoPage.verifyLoginSuccess();
  });

  it("HU-002: Login Fallido con Credenciales Inválidas", () => {
    LoginPage.fillCredentials("invalid_user", "wrong_password");
    LoginPage.clickLogin();
    LoginPage.verifyErrorMessage();
  });

  it("HU-003: Logout Exitoso", () => {
    LoginPage.fillCredentials("standard_user", "secret_sauce");
    LoginPage.clickLogin();
    SauceDemoPage.verifyLoginSuccess();
    SauceDemoPage.logout();
    SauceDemoPage.verifyLogoutSuccess();
  });
});

describe("B. Suite Productos y Carrito", () => {
  beforeEach(() => {
    LoginPage.visit();
    LoginPage.fillCredentials("standard_user", "secret_sauce");
    LoginPage.clickLogin();
    SauceDemoPage.verifyLoginSuccess();
  });

  it("HU-004: Obtener Lista de Productos", () => {
    cy.get(SauceDemoPage.inventoryItems).should("have.length", 6);
  });

  it("HU-005: Agregar Producto al Carrito", () => {
    SauceDemoPage.addProductToCart(0);
    cy.get(SauceDemoPage.cartButton).should("contain", "1");
    cy.get(SauceDemoPage.removeButton).first().should("contain", "Remove");
  });

  it("HU-006: Remover Producto del Carrito", () => {
    SauceDemoPage.addProductToCart(0);
    SauceDemoPage.removeProductFromCart(0);
    cy.get(SauceDemoPage.cartButton).should("not.contain", "1");
    cy.get(SauceDemoPage.addToCartButton)
      .first()
      .should("contain", "Add to cart");
  });

  it("HU-007: Ver Carrito de Compras", () => {
    SauceDemoPage.addProductToCart(0);
    SauceDemoPage.goToCart();
    cy.get(SauceDemoPage.cartItems).should("have.length", 1);
    cy.url().should("include", "/cart.html");
  });

  it("HU-008: Ordenar Productos por Precio", () => {
    SauceDemoPage.sortProductsByPriceLowToHigh();
    SauceDemoPage.getFirstProductPrice().should("contain", "7.99");
  });

  it("HU-009: Completar Información de Checkout", () => {
    SauceDemoPage.addProductToCart(0);
    SauceDemoPage.goToCart();
    SauceDemoPage.proceedToCheckout();
    SauceDemoPage.fillCheckoutInfo("Juan", "Perez", "12345");
    cy.url().should("include", "/checkout-step-two.html");
  });

  it("HU-010: Finalizar Compra", () => {
    SauceDemoPage.addProductToCart(0);
    SauceDemoPage.goToCart();
    SauceDemoPage.proceedToCheckout();
    SauceDemoPage.fillCheckoutInfo("Juan", "Perez", "12345");
    SauceDemoPage.completePurchase();
    cy.get(SauceDemoPage.completeMessage).should(
      "contain",
      "Thank you for your order"
    );
  });
});
