class SauceDemoPage {
  usernameInput = "#user-name";
  passwordInput = "#password";
  loginButton = "#login-button";
  menuButton = "#react-burger-menu-btn";
  logoutButton = "#logout_sidebar_link";
  inventoryItems = ".inventory_item";
  addToCartButton = ".btn_inventory";
  cartButton = ".shopping_cart_link";
  cartItems = ".cart_item";
  removeButton = ".btn_inventory";
  sortDropdown = ".product_sort_container";
  productNames = ".inventory_item_name";
  productPrices = ".inventory_item_price";
  checkoutButton = "#checkout";
  continueButton = "#continue";
  finishButton = "#finish";
  completeMessage = ".complete-header";

  login(username, password) {
    cy.get(this.usernameInput).type(username);
    cy.get(this.passwordInput).type(password);
    cy.get(this.loginButton).click();
  }

  logout() {
    cy.get(this.menuButton).click();
    cy.get(this.logoutButton).click();
  }

  addProductToCart(index = 0) {
    cy.get(this.addToCartButton).eq(index).click();
  }

  removeProductFromCart(index = 0) {
    cy.get(this.removeButton).eq(index).click();
  }

  goToCart() {
    cy.get(this.cartButton).click();
  }

  sortProductsByPriceLowToHigh() {
    cy.get(this.sortDropdown).select("lohi");
  }

  getFirstProductPrice() {
    return cy.get(this.productPrices).first();
  }

  proceedToCheckout() {
    cy.get(this.checkoutButton).click();
  }

  fillCheckoutInfo(firstName, lastName, zipCode) {
    cy.get("#first-name").type(firstName);
    cy.get("#last-name").type(lastName);
    cy.get("#postal-code").type(zipCode);
    cy.get(this.continueButton).click();
  }

  completePurchase() {
    cy.get(this.finishButton).click();
  }

  verifyLoginSuccess() {
    cy.url().should("include", "/inventory.html");
    cy.get(this.inventoryItems).should("have.length.at.least", 1);
  }

  verifyLogoutSuccess() {
    cy.url().should("include", "/index.html");
    cy.get(this.usernameInput).should("be.visible");
  }
}

export default new SauceDemoPage();
