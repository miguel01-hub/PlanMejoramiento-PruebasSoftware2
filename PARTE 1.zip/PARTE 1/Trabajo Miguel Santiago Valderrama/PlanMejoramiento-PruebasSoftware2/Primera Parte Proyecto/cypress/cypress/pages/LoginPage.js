class LoginPage {
  usernameInput = "#user-name";
  passwordInput = "#password";
  loginButton = "#login-button";
  errorMessage = "[data-test='error']";

  visit() {
    cy.visit("/");
  }

  fillCredentials(username, password) {
    cy.get(this.usernameInput).type(username);
    cy.get(this.passwordInput).type(password);
  }

  clickLogin() {
    cy.get(this.loginButton).click();
  }

  verifyErrorMessage() {
    cy.get(this.errorMessage).should("be.visible");
  }
}

export default new LoginPage();
